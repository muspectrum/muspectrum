<p>&copy; <?php echo date("Y"); ?> <?php config('server_name'); ?></p>
<p>This site is in no way associated with or endorsed by Webzen Inc.</p>