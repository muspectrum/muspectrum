<?php
$extra_admincp_sidebar[] = array(
    'Paymentwall', array(
        array('Settings','paymentwall')
    )
);